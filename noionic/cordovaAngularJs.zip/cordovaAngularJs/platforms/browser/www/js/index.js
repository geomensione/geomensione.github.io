angular.module("c_a", []) 
.controller("ACController", function($scope) {
	var number = 2;
	$scope.c_a_label = 'cordova label';
	
	$scope.changeLabel = () => {
		$scope.c_a_label = 'cordova label '+number;
		number++;
	} 
});