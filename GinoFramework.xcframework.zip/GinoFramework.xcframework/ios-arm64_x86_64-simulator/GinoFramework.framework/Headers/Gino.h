//
//  Gino.h
//  GinoFramework
//
//  Created by Alberto Paganelli on 01/06/16.
//  Copyright © 2016 DQuid. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Gino : NSObject

/**
 *  The name of the BLE device
 */
@property(nonatomic, readonly) NSString* name;

/**
 *  The serialunique identifier of the BLE device
 */
@property(nonatomic, readonly) NSString* serial;

/**
 *  The companyId of the BLE device
 */
@property(nonatomic, readonly) UInt16 companyId;

/**
 *  The customId of the BLE device
 */
@property(nonatomic, readonly) UInt16 customId;

/**
 *  The list of all the properties of the Gino
 */
@property(nonatomic, readonly) NSDictionary* properties;

/**
 * Get the properties for the provided channel
 * @param channel The channel for which get properties
 * @return An NSDictionary containing the properties of this object for the given cahnnel, in the form of key (Property Name) - Value (DQProperty)
 */
-(NSDictionary *)getPropertiesForChannel:(UInt8)channel;

@end
