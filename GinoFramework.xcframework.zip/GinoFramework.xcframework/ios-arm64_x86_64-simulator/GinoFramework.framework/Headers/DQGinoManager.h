//
//  DQGinoManager.h
//  GinoFramework
//
//  Created by Alberto Paganelli on 14/03/16.
//  Copyright © 2016 DQuid. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "Gino.h"

@interface GinoVersion: NSObject
@property (readonly) UInt8 major;
@property (readonly) UInt8 minor;
@property (readonly) UInt8 build;
+(GinoVersion*)createWithMajor:(UInt8)major minor:(UInt8)minor build:(UInt8)build;
-(NSString*)description;
@end


typedef NS_ENUM(UInt8, BootloaderState) {
    BOOTLOADER_STATE_UNSUPPORTED=0,
    BOOTLOADER_STATE_FWS_CRC_FAIL=0xF0,
    BOOTLOADER_STATE_OK=0xF3,
    BOOTLOADER_STATE_CORRUPTED=0xF7,
    BOOTLOADER_STATE_MISSING=0xFF
    
};

/**
 * Generic connect mode. Each Hardware driver should implement it's own way to handle them
 */
typedef NS_ENUM(UInt8, ConnectMode) {
    CONNECT_MODE_ANY = 0,
    CONNECT_MODE_BOOTLOADER = 1,
    CONNECT_MODE_APPLICATION = 2
};



typedef NS_ENUM(UInt8, SampleMode) { //max 3bit
    SAMPLE_MODE_LAST = 0,
    SAMPLE_MODE_AVERAGE = 1,
    SAMPLE_MODE_MAX = 2,
    SAMPLE_MODE_MIN = 3,
    SAMPLE_MODE_ON_CHANGE = 4,
    SAMPLE_MODE_DISABLE = 7
};

typedef NS_ENUM(UInt8, SaveMode) { //max 3bit
    SAVE_MODE_DISABLED = 0,
    SAVE_MODE_SINGLE = 1,
    SAVE_MODE_ALL = 2
};

extern NSString * const kGpsTimeDateProperty;
extern NSString * const kGpsPositionProperty;
extern NSString * const kGpsSpeedDirectionProperty;
extern NSString * const kGpsSatelliteInfoProperty;
extern NSString * const kSDKToGino;
extern NSString * const kGinoToSDK;


/**
 * This macro allow to access the main instance of DQGinoManager.
 * It is equivalent to write "[DQGinoManager sharedController]"
 */
#define DQGINOMANAGER   [DQGinoManager sharedController]

#pragma mark - DQGinoManagerDelegate Protocol

/**
 * This protocol contains the methods needed to handle any event related withthe Sdk.
 *
 * The DQGinoManager main instance has a delegate that has to implement this protocol.
 */
@protocol DQGinoManagerDelegate <NSObject>

@optional
/**
 *  Method called every time a new Gino has been discovered.
 *
 *  @param gino The Gino discovered
 */
- (void) onNewGinoDiscovered:(Gino *)gino;

/**
 *  Method called every time a connection to a Gino has been correctly established
 *
 *  @param gino The connected Gino
 */
- (void) onConnectionEstablishedForGino:(Gino *)gino;

/**
 *  Method called every time a connection to a Gino fails
 *
 *  @param gino The Gino
 */
- (void) onConnectionFailedForGino:(Gino *)gino;

/**
 *  Method called every time a disconnection to a Gino happens.
 *
 *  @param gino The disconnected Gino
 */
- (void) onDisconnectionFromGino:(Gino *)gino;

/**
 *  Method called every time a property has been updated by the Gino
 *
 *  @param gino The Gino that receive the updates
 *  @param updates A dictionary containing all the data received. The key is the name of the property updated,
 *                 the object is a list of DQData
 */
- (void) onGino:(Gino *)gino receivedUpdates:(NSDictionary*)updates;

/**
 *  Method called every time a property has been updated by the Gino
 *
 *  @param gino The Gino that receive the updates
 *  @param updates A array containing all the data received. Each object of the array is a dictionary where key is the name of the property updated,
 *                 the object is a DQData
 */
- (void) onGino:(Gino *)gino receivedUpdatesArray:(NSArray*)updates;

/**
 * Mathod called every time a new packet is received by the Gino
 *
 * @param gino The connected Gino
 * @param size The size of the received packet
 * @param date The NSDate at which the packet has been received
 */
- (void) onGino:(Gino *)gino receivedDataOfSize:(NSUInteger)size atDate:(NSDate *)date;

/**
 * Mathod called when a response to GetApplicationVersion arrives
 */
- (void)onGino:(Gino *)gino receivedApplicationVersion:(GinoVersion*)appVersion
                                        libraryVersion:(GinoVersion*)libVersion;
/**
 * Mathod called when a response to GetBootloaderVersion arrives
 */
- (void)onGino:(Gino *)gino receivedBootloaderVersion:(GinoVersion*)bootloaderVersion;

/**
 * Mathod called when a response to GetBootloaderState arrives
*/
- (void)onGino:(Gino *)gino receivedBootloaderState:(BootloaderState)bootloaderState;

/**
 * Mathod called when Gino reset
 *
 * @param didReset NO in case of error, YES otherwise
*/
- (void)onGino:(Gino *)gino didReset:(BOOL)didReset;

/**
 * Method called when Gino complete firmware write successfully
 */
- (void)onGinoDidCompleteFirmwareWrite:(Gino *)gino;

/**
 * Method called when Gino complete firmware write with error
 * @param error The error occured
 */
- (void)onGinoDidCompleteFirmwareWrite:(Gino *)gino withError:(NSError*)error;

/**
 * Method called when bytes are written successfully to Gino in firmware update
 */
- (void)onGino:(Gino *)gino firmwareWriteProgress:(UInt32)progress total:(UInt32)total;


@end


#pragma mark - DQGinoManager Interface

/**
 * The DQGinoManager gives access to the main features of the Sdk.
 *
 * This class is intended to be used as a singleton.
 * You can use the macro DQGINOMANAGER or the Class method "sharedController" in order to access its main instance.
 */

@interface DQGinoManager : NSObject

//TEMP
@property(readonly)NSDictionary*gpsProperties;


+ (DQGinoManager *)sharedController;

/**
 * If setted to YES the names of the properties will be changed to be univocal
 */
@property (nonatomic) BOOL shoudAvoidPropertyNameDuplicates;

- (void) addDelegate:(id<DQGinoManagerDelegate>)delegateToAdd;
- (void) removeDelegate:(id<DQGinoManagerDelegate>) delegateToRemove;

/**
 Sets the developer key into the SDK

 @param developerKey The base64 developer key
 */
- (void) setDeveloperKey:(NSString *)developerKey;

/**
Sets the bootloader key for a specific companyId into the SDK

@param developerKey The base64 bootloader developer key
@param companyId The corresponding known companyId as an unsigned short
*/

- (void) setBootLoaderDeveloperKey:(NSString *)developerKey  forCompanyId:(UInt16)companyId;

/**
Sets the bootloader key for a specific companyId into the SDK

@param developerKey The base64 bootloader developer key
@param companyId The corresponding companyId. The companyId is an unsigned short written  as an hexadecimal number string from "0000" to "FFFF"
*/

- (void) setBootLoaderDeveloperKey:(NSString *)developerKey  forCompanyIdString:(NSString*)companyId;


/**
 *  Starts the discovery of Ginos in application connection mode
 */
- (void) startSearchingGino;

/**
 *  Starts the discovery of Ginos in a specific connection mode
 *
 *  @param mode current operating state for the discovered Ginos
 */
- (void) startSearchingGinoWithConnectMode:(ConnectMode)mode;


/**
 * Starts the discovery of Ginos  with the specified company ID
 *
 * @param companyId The company ID to look for, written  as a two digits hexadecimal number string
 */
- (void) startSearchingGinoWithCompanyIdString:(NSString *)companyId;

/**
 *  Starts the discovery of Ginos in a specific connection mode
 *
 *  @param mode current operating state for the discovered Ginos
 *  @param
 *  @param companyId companyId The company ID to look for. The companyId is an unsigned short written  as an hexadecimal number string from "0000" to "FFFF"

 */
- (void) startSearchingGinoWithConnectMode:(ConnectMode)mode companyIdString:(NSString *)companyId;


/**
 *  Stops the discovery of Ginos
 */
- (void) stopSearchingGino;

/**
 *  Connect to Gino
 *
 *  @param gino The Gino you want to connect
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) connectToGino:(Gino *)gino;


/**
 *  Connect to Gino in a specific connection mode
 *
 *  @param gino The Gino you want to connect
 *  @param mode Operating state for the connection
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) connectToGino:(Gino *)gino withMode:(ConnectMode)mode;

/**
 *  Disconnect from the Gino
 *
 *  @param gino The Gino you want to discconnect
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) disconnectFromGino:(Gino *)gino;

/**
 *  Get the name of all the properties of the connected Gino
 *
 *  @return A dictionary with property name as key and the DQProperty as value
 */
- (NSDictionary*) getPropertiesOfConnectedGino;

/**
 *  Import the Dbc database on the default CAN channel (0)
 *
 *  @param path The path of the database
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) importDbc:(NSString*)path;

/**
 *  Import the Dbc database on the specified CAN channel
 *
 *  @param path The path of the database
 *  @param channel The path of the database
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) importDbc:(NSString*)path onChannel:(int)channel;

#pragma mark - Subscription method

/**
 * Sends a read request for a certain property of the object
 *
 * The read value is sent back to the delegate object through the proper callback method.
 * 'onErrorOccurred' callback may be called subsequentially to any potential issue.
 *
 * @param property The name of the property whose value we are requesting
 */
- (BOOL) readProperty:(NSString *)property;

/**
 *  Start to receive updates for the selected property
 *
 *  @param property The names of the property you want to subscribe
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) subscribeToProperty:(NSString*)property;

/**
 *  Start to receive updates for the selected CAN/GPS property
 *
 *  @param property The name of the property (CAN signal) whose value we are requesting
 *  @param rate The speed at which request updates
 *  @param sampleMode The sample mode to use for parsing data
 *  @param saveMode The save mode for saving into flash the received CAN data
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) subscribeToProperty:(NSString*)property withRate:(UInt16)rate sampleMode:(UInt8)sampleMode andSaveMode:(UInt8)saveMode;

/**
 *  Start to receive updates for the selected properties
 *
 *  @param properties The names of the properties you want to subscribe
 *  @param rate       The rate which you will receive the updates, in milliseconds
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) subscribeToProperties:(NSArray*)properties withRate:(UInt16)rate;

/**
 *  Start to receive updates for the selected CAN properties
 *
 *  @param properties The names of the properties you want to subscribe
 *  @param rate The speed at which request updates
 *  @param sampleMode The sample mode to use for parsing data
 *  @param saveMode The save mode for saving into flash the received CAN data
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) subscribeToProperties:(NSArray*)properties withRate:(UInt16)rate sampleMode:(UInt8)sampleMode andSaveMode:(UInt8)saveMode;

/**
 *  Stop receiving updates from the selected property
 *
 *  @param property The names of the property you want to unsubscribe
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) unsubscribeFromProperty:(NSString*)property;

/**
 *  Stop receiving updates from the selected properties
 *
 *  @param properties The names of the properties you want to unsubscribe
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) unsubscribeFromProperties:(NSArray*)properties;

/**
 *  Start to receive updates for all the properties of the connected Gino
 *
 *  @param rate The rate which you will receive the updates, in milliseconds
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) subscribeToAllPropertiesWithRate:(UInt16)rate;

/**
 *  Stop receiving updates from the Gino
 *
 *  @return NO in case of error, YES otherwise
 */
- (BOOL) unsubscribeFromAllProperties;


/**
 * Sends a write request (data type is selected according to the writeDataType of the property) for a certain property of the object
 *
 * 'onErrorOccurred' callback may be called subsequentially to any potential issue.
 *
 * @param data The DQData to write
 * @param property The name of the DQProperty to write to
 *
 * @return YES if athe request was forwarded
 */
- (BOOL) writeData:(NSData *)data toProperty:(NSString *)property;

/**
 * Sends a write request for a certain CAN property of the object
 *
 * 'onErrorOccurred' callback may be called subsequentially to any potential issue.
 *
 * @param data The DQData to write
 * @param property The name of the DQProperty to write to
 * @param rate The sample time at which wite the data. A zero rate means "one shot"
 *
 * @return YES if athe request was forwarded
 */
- (BOOL) writeData:(NSData *)data toProperty:(NSString *)property withMode:(UInt8)mode atRate:(UInt16)rate;


/**
 * Request BootloaderVersion
 *
 * @return YES if the request was forwarded
 */
- (BOOL)requestBootloaderVersion;

/**
 * Request Application and Library versions
 *
 * @return YES if the request was forwarded
 */
- (BOOL)requestApplicationLibraryVersion;

/**
 * Request bootloader status of currently connected gino in Bootloader mode
 *
 * @return YES if the request was forwarded
 */
-(BOOL)requestBootloaderState;

/**
 * Reboot the connected Gino
 */
-(BOOL)resetGino;


/**
 * Write firmware to connected Gino
 *
 * @param firmware The NSData containing the firmware
 */
- (BOOL)writeFirmware:(NSData*)firmware;




@end
