//
//  GinoFramework.h
//  GinoFramework
//
//  Created by Alberto Paganelli on 10/03/16.
//  Copyright © 2016 DQuid. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <GinoFramework/DQGinoManager.h>
#import <GinoFramework/Gino.h>

//! Project version number for GinoFramework.
FOUNDATION_EXPORT double GinoFrameworkVersionNumber;

//! Project version string for GinoFramework.
FOUNDATION_EXPORT const unsigned char GinoFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GinoFramework/PublicHeader.h>


