//
//  DQGinoLogger.h
//  GinoFramework
//
//  Created by Alberto Paganelli on 11/04/16.
//  Copyright © 2016 DQuid. All rights reserved.
//
#import <Foundation/Foundation.h>

#define ADD_METHOD_NAME_AND_LINE_PREFIX(fmt, ...) [NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]
#define ADD_METHOD_NAME_PREFIX(fmt, ...) [NSString stringWithFormat:(@"%s: " fmt), __PRETTY_FUNCTION__, ##__VA_ARGS__]

#define DQGINOLOG_VERBOSE_GENERIC(fmt, ...) [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]     withLevel:DQGINOLOG_LEVEL_VERBOSE   andCategory:DQGINOLOG_CATEGORY_GENERIC];
#define DQGINOLOG_DEBUG_GENERIC(fmt, ...)   [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]     withLevel:DQGINOLOG_LEVEL_DEBUG     andCategory:DQGINOLOG_CATEGORY_GENERIC];
#define DQGINOLOG_INFO_GENERIC(fmt, ...)    [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]     withLevel:DQGINOLOG_LEVEL_INFO      andCategory:DQGINOLOG_CATEGORY_GENERIC];
#define DQGINOLOG_WARN_GENERIC(fmt, ...)    [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]     withLevel:DQGINOLOG_LEVEL_WARN      andCategory:DQGINOLOG_CATEGORY_GENERIC];
#define DQGINOLOG_ERROR_GENERIC(fmt, ...)   [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]     withLevel:DQGINOLOG_LEVEL_ERROR     andCategory:DQGINOLOG_CATEGORY_GENERIC];
#define DQGINOLOG_ASSERT_GENERIC(fmt, ...)  [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]     withLevel:DQGINOLOG_LEVEL_ASSERT    andCategory:DQGINOLOG_CATEGORY_GENERIC];


#define DQGINOLOG_VERBOSE(categpry, fmt, ...) [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s: " fmt), __PRETTY_FUNCTION__, ##__VA_ARGS__]                       withLevel:DQGINOLOG_LEVEL_VERBOSE   andCategory:categpry];
#define DQGINOLOG_DEBUG(categpry, fmt, ...)   [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s: " fmt), __PRETTY_FUNCTION__, ##__VA_ARGS__]                       withLevel:DQGINOLOG_LEVEL_DEBUG     andCategory:categpry];
#define DQGINOLOG_INFO(categpry, fmt, ...)    [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s: " fmt), __PRETTY_FUNCTION__, ##__VA_ARGS__]                       withLevel:DQGINOLOG_LEVEL_INFO      andCategory:categpry];
#define DQGINOLOG_WARN(categpry, fmt, ...)    [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]   withLevel:DQGINOLOG_LEVEL_WARN      andCategory:categpry];
#define DQGINOLOG_ERROR(categpry, fmt, ...)   [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]   withLevel:DQGINOLOG_LEVEL_ERROR     andCategory:categpry];
#define DQGINOLOG_ASSERT(categpry, fmt, ...)  [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s [Line %d]: " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__]   withLevel:DQGINOLOG_LEVEL_ASSERT    andCategory:categpry];

#define DQGINOLOG(categpry, level, fmt, ...) [DQGinoLogger logMessage:[NSString stringWithFormat:(@"%s: " fmt), __PRETTY_FUNCTION__, ##__VA_ARGS__]                        withLevel:level                 andCategory:categpry];


typedef NS_ENUM(int, DQ_GINO_LOG_LEVEL){
    DQGINOLOG_LEVEL_VERBOSE = 2,    // In "each" method - to give info about the compelte flow
    DQGINOLOG_LEVEL_DEBUG,          // When a method is called, if it is important
    DQGINOLOG_LEVEL_INFO,           // Info inside methods
    DQGINOLOG_LEVEL_WARN,           // When something may be wrong
    DQGINOLOG_LEVEL_ERROR,          // When any error occurred
    DQGINOLOG_LEVEL_ASSERT,         // Fundamental Steps
    DQGINOLOG_LEVEL_OFF //=INT_MAX  // No logs (default)
};

typedef NS_OPTIONS(int, DQ_GINO_LOG_CATEGORY){
    DQGINOLOG_CATEGORY_NONE             = 0,
    DQGINOLOG_CATEGORY_GENERIC          = 1 << 0,
    DQGINOLOG_CATEGORY_HW               = 1 << 1,
    DQGINOLOG_CATEGORY_ALL              = DQGINOLOG_CATEGORY_GENERIC | DQGINOLOG_CATEGORY_HW
};

@interface DQGinoLogger : NSObject

+ (void) setLogLevel:(DQ_GINO_LOG_LEVEL)logLevel;
+ (void) enableCategory:(DQ_GINO_LOG_CATEGORY) logCategory;
+ (void) disableCategory:(DQ_GINO_LOG_CATEGORY) logCategory;

+ (void) logMessage:(NSString*)message withLevel:(DQ_GINO_LOG_LEVEL)logLevel andCategory:(DQ_GINO_LOG_CATEGORY)logCategory;

@end
