let fr = 5;

function setup() {
  createCanvas(400, 400);
  frameRate(fr);
  
}
const itemArea = [
  {xm:75,xM:125,ym:225,yM:275,r:50},
  {xm:275,xM:325,ym:225,yM:275,r:50},
  {xm:175,xM:225,ym:125,yM:175,r:50},
  {xm:75,xM:125,ym:325,yM:375,r:50},
  {xm:275,xM:325,ym:325,yM:375,r:50},
  {xm:150,xM:250,ym:200,yM:300,r:50}
]
const L_ARM=0,R_ARM=1,HEAD=2,L_LEG=3,R_LEG=4,BODY=itemArea.length-1;

function draw() {
  background(220);
  fill(0);
  for(let i = 0,l = itemArea.length;i<l;i++){
    rect(itemArea[i].xm,itemArea[i].ym,itemArea[i].xM-itemArea[i].xm,itemArea[i].yM-itemArea[i].ym)
  }
  
  let ro2 = itemArea[BODY];
  let x2 = random(ro2.xm,ro2.xM);
  let y2 = random(ro2.ym,ro2.yM);
  let r2 = random(ro2.r);
  let blueValue = color(random(255),random(255),random(255));
  fill(blueValue);
  for(let i = 0,l = itemArea.length;i<l-1;i++){
    let ro1 = itemArea[i];
    let x1 = random(ro1.xm,ro1.xM);
    let y1 = random(ro1.ym,ro1.yM);
    let r1 = random(ro1.r);
    circle(x1,y1,r1);
    interpolate(10,x1,y1,r1,x2,y2,r2); 
  }
  
  circle(x2,y2,r2);
  //noLoop();
}

function interpolate(n,x1,y1,r1,x2,y2,r2){
  let nx = (x2-x1)/n;
  let ny = (y2-y1)/n;
  let nr = (r2-r1)/n;
  for(let i = 0;i<n;i++){
    circle(x1+=nx,y1+=ny,r1+=nr)
  }
}
